# LocalSnapshots.ixi
A tool for fetching data from a running node's local snapshots. 
